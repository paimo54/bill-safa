# SALFANET RADIUS - Deployment Guide

Panduan lengkap untuk deploy SALFANET RADIUS ke VPS baru.

> **Latest Update:** December 7, 2025 - Subdomain & SSL Configuration

## 📋 Prerequisites

- Ubuntu 20.04/22.04 LTS
- Minimum 2GB RAM, 20GB Storage
- Root access
- Domain name (optional, untuk SSL/HTTPS)

## 🚀 Quick Deploy (From Backup)

### 1. Upload Project ke VPS

```bash
# Dari komputer lokal
scp -r salfanet-radius-main root@YOUR_VPS_IP:/root/
```

### 2. Install Dependencies

```bash
ssh root@YOUR_VPS_IP

# Update system
apt update && apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install MySQL 8.0
apt install -y mysql-server

# Install FreeRADIUS
apt install -y freeradius freeradius-mysql freeradius-utils

# Install Nginx
apt install -y nginx

# Install PM2
npm install -g pm2
```

### 3. Setup Database

```bash
# Login ke MySQL
mysql -u root

# Create database and user
CREATE DATABASE salfanet_radius CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'salfanet_user'@'localhost' IDENTIFIED BY 'salfanetradius123';
GRANT ALL PRIVILEGES ON salfanet_radius.* TO 'salfanet_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import database backup
cd /root/salfanet-radius-main
mysql -u salfanet_user -psalfanetradius123 salfanet_radius < backup/salfanet_radius_backup_20251203.sql
```

### 4. Setup FreeRADIUS

```bash
# Extract FreeRADIUS config backup
cd /root/salfanet-radius-main/backup
tar -xzf freeradius-config-20251203.tar.gz -C /etc/freeradius/

# Update SQL credentials di /etc/freeradius/3.0/mods-enabled/sql
nano /etc/freeradius/3.0/mods-enabled/sql
# Set: login = "salfanet_user", password = "salfanetradius123"

# Update REST URL di /etc/freeradius/3.0/mods-enabled/rest
nano /etc/freeradius/3.0/mods-enabled/rest
# Set: uri = "http://127.0.0.1:3000/api/radius/post-auth"

# Test configuration
freeradius -XC

# Enable and start FreeRADIUS
systemctl enable freeradius
systemctl start freeradius
```

### 5. Setup Application

```bash
cd /root/salfanet-radius-main

# Copy to /var/www
mkdir -p /var/www/salfanet-radius
cp -r * /var/www/salfanet-radius/
cd /var/www/salfanet-radius

# Setup .env
cp backup/env-production-20251203 .env
# Edit .env sesuai kebutuhan
nano .env

# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Build application
npm run build
```

### 6. Setup PM2

```bash
cd /var/www/salfanet-radius

# Start dengan PM2
pm2 start ecosystem.config.js

# Save PM2 config
pm2 save

# Setup PM2 startup
pm2 startup
```

### 7. Setup Nginx

```bash
# Copy nginx config
cp /var/www/salfanet-radius/backup/nginx-salfanet-radius.conf /etc/nginx/sites-available/salfanet-radius

# Edit server_name sesuai domain/IP
nano /etc/nginx/sites-available/salfanet-radius

# Enable site
ln -s /etc/nginx/sites-available/salfanet-radius /etc/nginx/sites-enabled/

# Test dan restart nginx
nginx -t
systemctl restart nginx
```

### 8. Setup Firewall

```bash
ufw allow 22/tcp     # SSH
ufw allow 80/tcp     # HTTP
ufw allow 443/tcp    # HTTPS
ufw allow 1812/udp   # RADIUS Auth
ufw allow 1813/udp   # RADIUS Accounting
ufw allow 3799/udp   # RADIUS CoA
ufw enable
```

## 📁 Backup Files

| File | Deskripsi |
|------|-----------|
| `backup/salfanet_radius_backup_20251203.sql` | Database backup |
| `backup/freeradius-config-20251203.tar.gz` | FreeRADIUS config |
| `backup/env-production-20251203` | Environment variables |
| `backup/nginx-salfanet-radius.conf` | Nginx config |
| `backup/ecosystem.config.js` | PM2 config |

## 🔧 Configuration Files

### .env (Environment Variables)

```env
DATABASE_URL="mysql://salfanet_user:salfanetradius123@localhost:3306/salfanet_radius?connection_limit=10&pool_timeout=20"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://YOUR_VPS_IP"
RADIUS_COA_SECRET="secret123"
RADIUS_COA_PORT="3799"
```

### ecosystem.config.js (PM2)

```javascript
module.exports = {
  apps: [{
    name: 'salfanet-radius',
    script: 'npm',
    args: 'start',
    cwd: '/var/www/salfanet-radius',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
}
```

### Nginx Config

```nginx
server {
    listen 80;
    server_name YOUR_DOMAIN_OR_IP;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 🔌 MikroTik Configuration

### RADIUS Client Setup

```
/radius
add address=YOUR_VPS_IP secret=secret123 service=ppp,hotspot timeout=3s

/radius incoming
set accept=yes port=3799
```

### PPPoE Server Setup

```
/ppp profile
add name=10M rate-limit=10M/10M
add name=20M rate-limit=20M/20M

/ppp aaa
set use-radius=yes accounting=yes
```

### Hotspot Setup

```
/ip hotspot profile
set [find default=yes] use-radius=yes radius-accounting=yes
```

## ✅ Verification

### Test FreeRADIUS

```bash
# Test PPPoE user
radtest 'user@realm' 'password' 127.0.0.1 0 testing123

# Test Hotspot voucher
radtest 'vouchercode' 'password' 127.0.0.1 0 testing123
```

### Test CoA

```bash
# Test CoA connection to MikroTik
curl -X POST http://localhost:3000/api/radius/coa \
  -H "Content-Type: application/json" \
  -d '{"action":"test","host":"MIKROTIK_IP"}'
```

### Test Application

```bash
# Check PM2 status
pm2 status

# Check logs
pm2 logs salfanet-radius

# Check nginx
systemctl status nginx

# Check FreeRADIUS
systemctl status freeradius
```

## 📝 Credentials

### Default Admin Login
- **URL**: http://YOUR_VPS_IP/admin/login
- **Username**: superadmin
- **Password**: admin123

⚠️ **Change password immediately after login!**

### Database
- **User**: salfanet_user
- **Password**: salfanetradius123
- **Database**: salfanet_radius

### RADIUS Secret
- **Secret**: secret123 (sesuaikan dengan MikroTik)

## 🔄 Maintenance Commands

```bash
# Restart application
pm2 restart salfanet-radius

# View logs
pm2 logs salfanet-radius --lines 100

# Rebuild application
cd /var/www/salfanet-radius
npm run build
pm2 restart salfanet-radius

# Backup database
mysqldump -u salfanet_user -psalfanetradius123 salfanet_radius > backup.sql

# Restart FreeRADIUS
systemctl restart freeradius

# Debug FreeRADIUS
systemctl stop freeradius
freeradius -X
```

## 🆘 Troubleshooting

### Application tidak bisa diakses
```bash
pm2 status
pm2 logs salfanet-radius
nginx -t
systemctl restart nginx
```

### RADIUS authentication gagal
```bash
systemctl stop freeradius
freeradius -X
# Check log untuk error detail
```

### CoA tidak berfungsi
```bash
# Pastikan MikroTik sudah enable CoA
# /radius incoming set accept=yes port=3799

# Test dengan radclient
echo "User-Name=testuser" | radclient -x MIKROTIK_IP:3799 coa secret123
```

### Database connection error
```bash
mysql -u salfanet_user -psalfanetradius123 salfanet_radius -e "SELECT 1"
# Check .env DATABASE_URL
```

### Dashboard statistics showing Rp 0 or 0 users
```bash
# Check PM2 logs for transaction count
pm2 logs salfanet-radius | grep "transactionCount"

# Verify database has transactions
mysql -u salfanet_user -psalfanetradius123 salfanet_radius -e "SELECT COUNT(*) FROM transactions WHERE type='INCOME'"

# Restart PM2 with updated environment
pm2 restart salfanet-radius --update-env
```

---

## 🌐 Setup Subdomain & SSL (Optional)

### 1. Generate Self-Signed Certificate

```bash
# Create SSL directory
sudo mkdir -p /etc/ssl/YOUR_DOMAIN

# Generate certificate (valid 1 year)
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/YOUR_DOMAIN/privkey.pem \
  -out /etc/ssl/YOUR_DOMAIN/fullchain.pem \
  -subj "/C=ID/ST=Jakarta/L=Jakarta/O=YourCompany/CN=YOUR_DOMAIN"

# Set permissions
sudo chmod 600 /etc/ssl/YOUR_DOMAIN/privkey.pem
sudo chmod 644 /etc/ssl/YOUR_DOMAIN/fullchain.pem
```

### 2. Update Nginx Configuration

```nginx
server {
    listen 80;
    server_name YOUR_DOMAIN;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name YOUR_DOMAIN;

    ssl_certificate /etc/ssl/YOUR_DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/ssl/YOUR_DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 3. Update Environment Variable

```bash
cd /var/www/salfanet-radius
sudo nano .env
# Change: NEXTAUTH_URL=https://YOUR_DOMAIN
```

### 4. Restart Services

```bash
# Test Nginx config
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Restart PM2 with updated env
sudo pm2 restart salfanet-radius --update-env
```

### 5. Firewall (Allow HTTPS)

```bash
sudo ufw allow 443/tcp
sudo ufw reload
```

### 6. Cloudflare Setup (If using Cloudflare)

- Add A record pointing to your VPS IP
- Enable proxy (orange cloud) for CDN protection
- Set SSL/TLS mode to "Full" (accepts self-signed from origin)
- Wait for DNS propagation (5-10 minutes)

---

Last Updated: December 3, 2025
