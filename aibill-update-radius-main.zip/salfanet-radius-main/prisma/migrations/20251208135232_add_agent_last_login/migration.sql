-- AlterTable
ALTER TABLE `agents` ADD COLUMN `lastLogin` DATETIME(3) NULL;
