-- Fix voucher template v10 - support username/password side by side
-- 50 voucher per halaman: landscape 5x10, portrait 10x5
-- Ukuran sama untuk code only dan username/password

UPDATE voucher_templates 
SET htmlTemplate = '{include file="rad-template-header.tpl"}
{foreach $v as $vs}
{if $vs[''code''] eq $vs[''secret'']}
<div style="display: inline-block; width: 18.5%; border: 1px solid #ccc; border-radius: 3px; font-family: Arial, sans-serif; margin: 0.5%; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid; box-sizing: border-box;">
<div style="background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 8px; font-weight: bold;">
{$vs[''router_name'']}
</div>
<div style="padding: 3px 4px;">
<div style="color: #ff8c00; font-size: 6px; font-weight: 600;">Kode Voucher</div>
<div style="font-family: ''Courier New'', monospace; font-size: 11px; font-weight: bold; color: #000; line-height: 1.2;">{$vs[''code'']}</div>
</div>
<div style="border-top: 1px dashed #ffa500; padding: 2px 4px; font-size: 8px; font-weight: bold; color: #000;">
{$vs[''validity'']} - {$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
{else}
<div style="display: inline-block; width: 18.5%; border: 1px solid #ccc; border-radius: 3px; font-family: Arial, sans-serif; margin: 0.5%; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid; box-sizing: border-box;">
<div style="background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 8px; font-weight: bold;">
{$vs[''router_name'']}
</div>
<div style="padding: 2px 4px;">
<div style="display: flex; gap: 4px;">
<div style="flex: 1;">
<div style="color: #ff8c00; font-size: 5px; font-weight: 600;">Username</div>
<div style="font-family: ''Courier New'', monospace; font-size: 9px; font-weight: bold; color: #000; line-height: 1.1;">{$vs[''code'']}</div>
</div>
<div style="flex: 1;">
<div style="color: #ff8c00; font-size: 5px; font-weight: 600;">Password</div>
<div style="font-family: ''Courier New'', monospace; font-size: 9px; font-weight: bold; color: #000; line-height: 1.1;">{$vs[''secret'']}</div>
</div>
</div>
</div>
<div style="border-top: 1px dashed #ffa500; padding: 2px 4px; font-size: 8px; font-weight: bold; color: #000;">
{$vs[''validity'']} - {$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
{/if}
{/foreach}
{include file="rad-template-footer.tpl"}',
updatedAt = NOW()
WHERE isDefault = true OR name = 'Default Template';
