-- Fix voucher template v8 - support username/password, router name, validity
-- Card ukuran pas, ada space antar voucher, tampilkan router name dan validity

UPDATE voucher_templates 
SET htmlTemplate = '{include file="rad-template-header.tpl"}
{foreach $v as $vs}
{if $vs[''code''] eq $vs[''secret'']}
<div style="display: inline-block; width: 115px; border: 1px solid #ddd; border-radius: 4px; font-family: Arial, sans-serif; margin: 2px; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid;">
<div style="background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 9px; font-weight: bold;">
{$vs[''router_name'']}
</div>
<div style="padding: 2px 4px;">
<div style="color: #ff8c00; font-size: 7px; font-weight: 600;">Kode Voucher</div>
<div style="font-family: ''Courier New'', monospace; font-size: 13px; font-weight: bold; color: #000; line-height: 1.1;">{$vs[''code'']}</div>
</div>
<div style="border-top: 1px dashed #ffa500; padding: 2px 4px;">
<div style="color: #ff8c00; font-size: 7px; font-weight: 600;">Harga</div>
<div style="font-size: 10px; font-weight: bold; color: #000;">{$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
<div style="border-top: 1px solid #eee; padding: 2px 4px; font-size: 7px; color: #666;">
{$vs[''validity'']}
</div>
</div>
{else}
<div style="display: inline-block; width: 115px; border: 1px solid #ddd; border-radius: 4px; font-family: Arial, sans-serif; margin: 2px; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid;">
<div style="background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 9px; font-weight: bold;">
{$vs[''router_name'']}
</div>
<div style="padding: 2px 4px;">
<div style="color: #ff8c00; font-size: 7px; font-weight: 600;">Username</div>
<div style="font-family: ''Courier New'', monospace; font-size: 11px; font-weight: bold; color: #000; line-height: 1.1;">{$vs[''code'']}</div>
<div style="color: #ff8c00; font-size: 7px; font-weight: 600; margin-top: 2px;">Password</div>
<div style="font-family: ''Courier New'', monospace; font-size: 11px; font-weight: bold; color: #000; line-height: 1.1;">{$vs[''secret'']}</div>
</div>
<div style="border-top: 1px dashed #ffa500; padding: 2px 4px;">
<div style="color: #ff8c00; font-size: 7px; font-weight: 600;">Harga</div>
<div style="font-size: 10px; font-weight: bold; color: #000;">{$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
<div style="border-top: 1px solid #eee; padding: 2px 4px; font-size: 7px; color: #666;">
{$vs[''validity'']}
</div>
</div>
{/if}
{/foreach}
{include file="rad-template-footer.tpl"}',
updatedAt = NOW()
WHERE isDefault = true OR name = 'Default Template';
