-- Fix voucher template v7 - compact like reference image
-- Card size pas dengan layout, ada space antar voucher, no extra padding
-- Using supported template syntax

UPDATE voucher_templates 
SET htmlTemplate = '{include file=\"rad-template-header.tpl\"}
{foreach $v as $vs}
{if $vs[''code''] eq $vs[''secret'']}
<div style=\"display: inline-block; width: 115px; border: 1px solid #ddd; border-radius: 4px; font-family: Arial, sans-serif; margin: 2px; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid;\">
<div style=\"background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 9px; font-weight: bold;\">
{company_name}
</div>
<div style=\"padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Kode Voucher</div>
<div style=\"font-family: ''Courier New'', monospace; font-size: 13px; font-weight: bold; color: #000; line-height: 1.1;\">{$vs[''code'']}</div>
</div>
<div style=\"border-top: 1px dashed #ffa500; padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Harga</div>
<div style=\"font-size: 10px; font-weight: bold; color: #000;\">{$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
<div style=\"border-top: 1px solid #eee; padding: 2px 4px; font-size: 7px; color: #666;\">
{$vs[''profile_name'']}
</div>
</div>
{else}
<div style=\"display: inline-block; width: 115px; border: 1px solid #ddd; border-radius: 4px; font-family: Arial, sans-serif; margin: 2px; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid;\">
<div style=\"background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 9px; font-weight: bold;\">
{company_name}
</div>
<div style=\"padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Kode Voucher</div>
<div style=\"font-family: ''Courier New'', monospace; font-size: 12px; font-weight: bold; color: #000; line-height: 1.1;\">{$vs[''code'']}</div>
</div>
<div style=\"border-top: 1px dashed #ffa500; padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Harga</div>
<div style=\"font-size: 10px; font-weight: bold; color: #000;\">{$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
<div style=\"border-top: 1px solid #eee; padding: 2px 4px; font-size: 7px; color: #666;\">
{$vs[''profile_name'']}
</div>
</div>
{/if}
{/foreach}
{include file=\"rad-template-footer.tpl\"}',
updatedAt = NOW()
WHERE isDefault = true OR name = 'Default Template';

-- If no default template exists, insert one
INSERT INTO voucher_templates (id, name, htmlTemplate, isDefault, isActive, createdAt, updatedAt)
SELECT 
  UUID(),
  'Default Template',
  '{include file=\"rad-template-header.tpl\"}
{assign var=\"counter\" value=1}
{foreach $v as $vs}
{if $vs[''code''] eq $vs[''secret'']}
<div style=\"display: inline-block; width: 115px; border: 1px solid #ddd; border-radius: 4px; font-family: Arial, sans-serif; margin: 2px; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid; font-size: 0;\">
<div style=\"background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 10px; font-weight: bold; position: relative;\">
<span style=\"font-size: 9px;\">{$_c[''CompanyName'']}</span>
<span style=\"position: absolute; right: 3px; top: 2px; background: #fff; color: #ff8c00; border-radius: 50%; width: 14px; height: 14px; font-size: 8px; line-height: 14px; text-align: center;\">{$counter}</span>
</div>
<div style=\"padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Kode Voucher</div>
<div style=\"font-family: ''Courier New'', monospace; font-size: 13px; font-weight: bold; color: #000; line-height: 1.1;\">{$vs[''code'']}</div>
</div>
<div style=\"border-top: 1px dashed #ffa500; padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Harga</div>
<div style=\"font-size: 10px; font-weight: bold; color: #000;\">{$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
<div style=\"border-top: 1px solid #eee; padding: 2px 4px; display: flex; justify-content: space-between; align-items: center;\">
<span style=\"font-size: 7px; color: #666;\">{$vs[''routers'']}-{$vs[''name'']}</span>
<span style=\"font-size: 8px; font-weight: bold; color: #333;\">{$vs[''time_limit'']}</span>
</div>
</div>
{else}
<div style=\"display: inline-block; width: 115px; border: 1px solid #ddd; border-radius: 4px; font-family: Arial, sans-serif; margin: 2px; padding: 0; vertical-align: top; background: #fff; page-break-inside: avoid; font-size: 0;\">
<div style=\"background: #ff8c00; color: #fff; padding: 2px 4px; font-size: 10px; font-weight: bold; position: relative;\">
<span style=\"font-size: 9px;\">{$_c[''CompanyName'']}</span>
<span style=\"position: absolute; right: 3px; top: 2px; background: #fff; color: #ff8c00; border-radius: 50%; width: 14px; height: 14px; font-size: 8px; line-height: 14px; text-align: center;\">{$counter}</span>
</div>
<div style=\"padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Kode Voucher</div>
<div style=\"font-family: ''Courier New'', monospace; font-size: 12px; font-weight: bold; color: #000; line-height: 1.1;\">{$vs[''code'']}</div>
</div>
<div style=\"border-top: 1px dashed #ffa500; padding: 2px 4px;\">
<div style=\"color: #ff8c00; font-size: 7px; font-weight: 600;\">Harga</div>
<div style=\"font-size: 10px; font-weight: bold; color: #000;\">{$_c[''currency_code'']}. {number_format($vs[''total''], 0, '','', ''.'')}</div>
</div>
<div style=\"border-top: 1px solid #eee; padding: 2px 4px; display: flex; justify-content: space-between; align-items: center;\">
<span style=\"font-size: 7px; color: #666;\">{$vs[''routers'']}-{$vs[''name'']}</span>
<span style=\"font-size: 8px; font-weight: bold; color: #333;\">{$vs[''time_limit'']}</span>
</div>
</div>
{/if}
{assign var=\"counter\" value=$counter+1}
{/foreach}
{include file=\"rad-template-footer.tpl\"}',
  true,
  true,
  NOW(),
  NOW()
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM voucher_templates WHERE isDefault = true);
