# FreeRADIUS Configuration Backup

## 📅 Last Backup Date
**2025-12-13 09:50 WIB**

---

## 📍 Source Information
- **VPS IP:** 103.67.244.131
- **FreeRADIUS Version:** 3.0.26
- **Config Path:** `/etc/freeradius/3.0/`
- **Server:** Ubuntu 22.04 LTS

---

## 📦 Backed Up Files

### 1. **sites-enabled-default** (35.2 KB)
- Main FreeRADIUS virtual server configuration
- **Critical Change:** Line 436 contains `rest` module call in authorize section
- **Location:** `/etc/freeradius/3.0/sites-enabled/default`
- **Purpose:** Authorization flow (SQL → REST → PAP)

**Key Section:**
```
authorize {
    # ... other modules ...
    -sql          # Load from radcheck/radusergroup
    rest          # ← NEW: Validate voucher expiry
    -ldap
    # ... other modules ...
    pap
}
```

---

### 2. **mods-enabled-rest** (1.9 KB)
- REST module configuration for API calls
- **Location:** `/etc/freeradius/3.0/mods-enabled/rest`
- **Purpose:** Call Next.js API for authorize, post-auth, accounting

**Sections:**
```
rest {
    connect_uri = "http://localhost:3000"
    
    # 1. authorize - Pre-authentication check (NEW)
    authorize {
        uri = "${..connect_uri}/api/radius/authorize"
        timeout = 2
    }
    
    # 2. post-auth - Success/failure logging
    post-auth {
        uri = "${..connect_uri}/api/radius/post-auth"
    }
    
    # 3. accounting - Session tracking
    accounting {
        uri = "${..connect_uri}/api/radius/accounting"
    }
}
```

**Note:** Contains `jsonExtract` section (commented/not used in FreeRADIUS 3.0.26)

---

### 3. **mods-enabled-sql** (1.1 KB)
- SQL module configuration
- **Location:** `/etc/freeradius/3.0/mods-enabled/sql`
- **Database:** MySQL salfanet_radius
- **Purpose:** Load user credentials from radcheck/radusergroup

**Configuration:**
```
sql {
    driver = "rlm_sql_mysql"
    dialect = "mysql"
    
    server = "localhost"
    port = 3306
    login = "salfanet_user"
    password = "salfanetradius123"
    radius_db = "salfanet_radius"
}
```

---

### 4. **clients.conf** (9.4 KB)
- RADIUS client (NAS) definitions
- **Location:** `/etc/freeradius/3.0/clients.conf`
- **Purpose:** Authenticate MikroTik and other NAS devices

**Example Client:**
```
client mikrotik {
    ipaddr = 192.168.1.1
    secret = radius_secret_key
    nas_type = mikrotik
}
```

---

## 🔄 Backup Archive

**Filename:** `freeradius-backup-20251213-0950.tar.gz`

**Extract Command:**
```bash
tar -xzf freeradius-backup-20251213-0950.tar.gz
```

**Contents:**
- sites-enabled-default
- mods-enabled-rest
- mods-enabled-sql
- clients.conf

---

## 📝 Important Changes (2025-12-13)

### ✅ REST Authorization Pre-Check
**What Changed:**
- Added `rest` module call in `sites-enabled-default` authorize section (line 436)
- REST API endpoint `/api/radius/authorize` validates voucher expiry BEFORE password check
- Returns `Auth-Type: Reject` for expired vouchers with message "Your account has expired"

**Why Important:**
- 🔒 **Security:** Prevents expired vouchers from logging in
- 📝 **UX:** Shows proper error message in MikroTik logs
- ⚡ **Real-time:** Validates business logic before authentication

**Authorization Flow:**
```
User Login
    ↓
SQL Module (load username/password from radcheck)
    ↓
REST Module (/api/radius/authorize)  ← NEW STEP
    ├─ Check: voucher.status === 'EXPIRED'?
    ├─ Check: voucher.expiresAt < now?
    └─ Check: active session timeout?
    ↓
PAP Module (password validation)
    ↓
Access-Accept / Access-Reject
```

---

## 🚀 Deployment Instructions

### To VPS (Deploy):
```bash
# 1. Upload config files
scp sites-enabled-default root@103.67.244.131:/etc/freeradius/3.0/sites-enabled/default
scp mods-enabled-rest root@103.67.244.131:/etc/freeradius/3.0/mods-enabled/rest
scp mods-enabled-sql root@103.67.244.131:/etc/freeradius/3.0/mods-enabled/sql
scp clients.conf root@103.67.244.131:/etc/freeradius/3.0/clients.conf

# 2. SSH to VPS
ssh root@103.67.244.131

# 3. Test configuration
freeradius -CX

# 4. Restart FreeRADIUS
systemctl restart freeradius

# 5. Verify status
systemctl status freeradius
```

### From VPS (Backup - THIS FILE):
```bash
# Download latest config from VPS
cd freeradius-config/
scp root@103.67.244.131:/etc/freeradius/3.0/sites-enabled/default sites-enabled-default
scp root@103.67.244.131:/etc/freeradius/3.0/mods-enabled/rest mods-enabled-rest
scp root@103.67.244.131:/etc/freeradius/3.0/mods-enabled/sql mods-enabled-sql
scp root@103.67.244.131:/etc/freeradius/3.0/clients.conf clients.conf

# Create backup archive
tar -czf freeradius-backup-$(date +%Y%m%d-%H%M).tar.gz \
    sites-enabled-default mods-enabled-rest mods-enabled-sql clients.conf
```

---

## ⚠️ Critical Notes

1. **Line Endings:**
   - All files use Unix LF (`\n`) line endings
   - Windows CRLF (`\r\n`) will cause "Line too long" error
   - Use UTF-8 encoding WITHOUT BOM

2. **Module Dependencies:**
   - `rlm_rest` module must be installed: `apt-get install freeradius-rest`
   - `rlm_sql_mysql` module required for MySQL connection

3. **API Endpoint:**
   - REST module calls `http://localhost:3000/api/radius/authorize`
   - Next.js app must be running on port 3000
   - Timeout set to 2 seconds (fallback to allow on error)

4. **jsonExtract Note:**
   - Config contains `jsonExtract` section in mods-enabled-rest
   - NOT supported in FreeRADIUS 3.0.26 (only 3.2+)
   - Response must use attribute prefixes: `control:`, `reply:`
   - Example: `{"control:Auth-Type": "Reject"}`

---

## 🔍 Verification Commands

### Check REST Module Loaded:
```bash
freeradius -X | grep -i rest
```

### Test Authorization Endpoint:
```bash
curl -X POST http://localhost:3000/api/radius/authorize \
  -H "Content-Type: application/json" \
  -d '{"username": "test_voucher"}'
```

### Debug Authentication:
```bash
# Terminal 1: FreeRADIUS debug
systemctl stop freeradius
freeradius -X

# Terminal 2: Test auth
radtest voucher_code voucher_code localhost 0 testing123
```

### Check Active Config:
```bash
# View authorize section
sed -n '/^authorize {/,/^}/p' /etc/freeradius/3.0/sites-enabled/default | grep -A5 -B5 rest
```

---

## 📊 File Comparison

| Config File | Production VPS | Local Backup | Status |
|-------------|----------------|--------------|--------|
| sites-enabled-default | 36,018 bytes | 35.2 KB | ✅ Synced |
| mods-enabled-rest | 1,930 bytes | 1.9 KB | ✅ Synced |
| mods-enabled-sql | 1,172 bytes | 1.1 KB | ✅ Synced |
| clients.conf | 9,670 bytes | 9.4 KB | ✅ Synced |

**Last Sync:** 2025-12-13 09:50 WIB

---

## 📚 Related Documentation

- [CHANGELOG.md](../CHANGELOG.md) - Version history with REST authorization feature
- [CHAT_MEMORY_VOUCHER_AUTHORIZATION.md](../CHAT_MEMORY_VOUCHER_AUTHORIZATION.md) - Technical implementation details
- [FREERADIUS-SETUP.md](../docs/FREERADIUS-SETUP.md) - Installation guide
- [FreeRADIUS REST Module Docs](https://networkradius.com/doc/3.0.26/raddb/mods-available/rest.html)

---

## 🆘 Troubleshooting

### Error: "Line too long"
**Cause:** File has wrong line endings (CRLF instead of LF)  
**Fix:**
```bash
dos2unix /etc/freeradius/3.0/sites-enabled/default
# or
sed -i 's/\r$//' /etc/freeradius/3.0/sites-enabled/default
```

### Error: "Module rlm_rest not found"
**Cause:** REST module not installed  
**Fix:**
```bash
apt-get install -y freeradius-rest
```

### Error: "Unknown section jsonExtract"
**Cause:** FreeRADIUS 3.0.26 doesn't support jsonExtract  
**Fix:** API response must use attribute prefixes:
```json
{
  "control:Auth-Type": "Reject",
  "reply:Reply-Message": "Your account has expired"
}
```

### REST API Timeout
**Symptom:** Authentication slow (2+ seconds)  
**Check:**
```bash
# Test API response time
time curl -X POST http://localhost:3000/api/radius/authorize \
  -H "Content-Type: application/json" \
  -d '{"username": "test"}'
```
**Expected:** < 100ms

---

## ✅ Backup Verification Checklist

- [x] All 4 config files downloaded from VPS
- [x] File sizes match production
- [x] Line endings are Unix LF (not CRLF)
- [x] Encoding is UTF-8 without BOM
- [x] `rest` call present in sites-enabled-default (line 436)
- [x] Backup archive created: `freeradius-backup-20251213-0950.tar.gz`
- [x] README documentation updated

---

**Backup Status:** ✅ **COMPLETE**  
**Last Updated:** 2025-12-13 09:50 WIB  
**Maintained By:** SALFANET RADIUS Team
