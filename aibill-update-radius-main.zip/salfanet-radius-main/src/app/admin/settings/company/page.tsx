'use client';

import { useState, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Building2, Mail, Phone, MapPin, Globe, Save, Loader2, RotateCcw } from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { setCurrentTimezone } from '@/lib/timezone';
import Swal from 'sweetalert2';

interface CompanySettings {
  id?: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  baseUrl: string;
  timezone: string;
}

export default function CompanySettingsPage() {
  const { t } = useTranslation();
  const { setCompany } = useAppStore();
  const [settings, setSettings] = useState<CompanySettings>({
    name: '',
    email: '',
    phone: '',
    address: '',
    baseUrl: '',
    timezone: 'Asia/Jakarta'
  });
  const [initialTimezone, setInitialTimezone] = useState('Asia/Jakarta');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [restarting, setRestarting] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/company');
      if (response.ok) {
        const data = await response.json();
        if (data) {
          setSettings({
            id: data.id || '',
            name: data.name || '',
            email: data.email || '',
            phone: data.phone || '',
            address: data.address || '',
            baseUrl: data.baseUrl || '',
            timezone: data.timezone || 'Asia/Jakarta',
          });
          setInitialTimezone(data.timezone || 'Asia/Jakarta');
        }
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  // Check if timezone has changed
  const timezoneChanged = settings.timezone !== initialTimezone;

  // Handle restart services
  const handleRestartServices = async () => {
    setRestarting(true);
    try {
      Swal.fire({
        title: 'Memproses...',
        html: `
          <div class="text-left">
            <p class="mb-2">Menyimpan dan menerapkan perubahan timezone...</p>
          </div>
        `,
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        didOpen: () => {
          Swal.showLoading();
        }
      });
      
      const restartResponse = await fetch('/api/settings/restart-services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ services: 'all', delay: 2000 })
      });
      
      const restartResult = await restartResponse.json();
      
      if (restartResult.success) {
        if (restartResult.autoRestarted) {
          // Linux production - services will restart
          Swal.fire({
            icon: 'success',
            title: 'Services Restarting',
            html: `
              <div class="text-left">
                <p class="mb-2">✅ Settings tersimpan!</p>
                <p class="mb-2">🔄 Services sedang restart:</p>
                <ul class="text-sm text-gray-600 list-disc pl-5 space-y-1">
                  <li>PM2 (Node.js Application)</li>
                  <li>FreeRADIUS Service</li>
                </ul>
                <p class="mt-3 text-xs text-gray-500">Halaman akan reload dalam 5 detik...</p>
              </div>
            `,
            allowOutsideClick: false,
            showConfirmButton: false,
            timer: 5000,
          });
          setTimeout(() => {
            window.location.reload();
          }, 5000);
        } else {
          // Development mode (Windows/Mac) - no restart needed
          Swal.fire({
            icon: 'success',
            title: 'Timezone Updated! ✅',
            html: `
              <div class="text-left">
                <p class="mb-3 text-green-600 font-medium">Perubahan timezone berhasil diterapkan!</p>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                  <p class="text-sm text-blue-800">
                    <strong>Development Mode:</strong> Timezone sudah langsung aktif di frontend.
                  </p>
                </div>
                ${restartResult.note ? `<p class="text-xs text-gray-500 mt-2">💡 ${restartResult.note}</p>` : ''}
              </div>
            `,
            confirmButtonText: 'OK',
            confirmButtonColor: '#14b8a6',
          }).then(() => {
            window.location.reload();
          });
        }
      } else {
        Swal.fire({
          icon: 'warning',
          title: 'Auto Restart Not Available',
          html: `
            <p class="mb-2">${restartResult.message}</p>
            <p class="text-sm text-gray-600">Silakan restart manual dengan command:</p>
            <div class="mt-3 p-3 bg-gray-900 text-gray-100 rounded text-xs font-mono text-left">
              pm2 restart all --update-env<br/>
              sudo systemctl restart freeradius
            </div>
          `,
        });
      }
    } catch (error) {
      console.error('Restart error:', error);
      Swal.fire({
        icon: 'error',
        title: 'Restart Failed',
        html: `
          <p class="mb-2">Gagal restart services otomatis.</p>
          <p class="text-sm text-gray-600">Silakan restart manual:</p>
          <div class="mt-3 p-3 bg-gray-900 text-gray-100 rounded text-xs font-mono text-left">
            pm2 restart all --update-env<br/>
            sudo systemctl restart freeradius
          </div>
        `,
      });
    } finally {
      setRestarting(false);
    }
  };

  // Handle save and restart
  const handleSaveAndRestart = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const response = await fetch('/api/company', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });

      if (response.ok) {
        setCompany({
          name: settings.name,
          email: settings.email,
          phone: settings.phone,
          address: settings.address,
          baseUrl: settings.baseUrl,
          timezone: settings.timezone,
        });
        setCurrentTimezone(settings.timezone);
        setInitialTimezone(settings.timezone);
        
        setSaving(false);
        await handleRestartServices();
      } else {
        throw new Error('Save failed');
      }
    } catch (error) {
      setSaving(false);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: t('settings.saveSettingsFailed')
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const response = await fetch('/api/company', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });

      if (response.ok) {
        // Update global store with new settings (including timezone)
        setCompany({
          name: settings.name,
          email: settings.email,
          phone: settings.phone,
          address: settings.address,
          baseUrl: settings.baseUrl,
          timezone: settings.timezone,
        });
        
        // Update timezone library
        setCurrentTimezone(settings.timezone);
        setInitialTimezone(settings.timezone);
        
        Swal.fire({
          icon: 'success',
          title: t('common.success'),
          text: t('settings.companySaved'),
          timer: 2000,
          showConfirmButton: false
        });
      } else {
        throw new Error(t('common.saveFailed'));
      }
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: t('settings.saveSettingsFailed')
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-5 h-5 animate-spin text-teal-600" />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-600 to-cyan-600 rounded-lg p-3 text-white">
        <div className="flex items-center gap-2">
          <Building2 className="w-4 h-4" />
          <div>
            <h1 className="text-base font-semibold">{t('settings.companySettings')}</h1>
            <p className="text-[11px] text-teal-100">{t('settings.manageCompanyInfo')}</p>
          </div>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-3">
        <div className="space-y-3">
          {/* Nama Perusahaan */}
          <div>
            <label className="flex items-center gap-1.5 text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
              <Building2 className="w-3 h-3" />
              {t('settings.companyName')}
            </label>
            <input
              type="text"
              value={settings.name}
              onChange={(e) => setSettings({ ...settings, name: e.target.value })}
              className="w-full px-2.5 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
              placeholder="Nama perusahaan Anda"
              required
            />
          </div>

          {/* Email & Phone - 2 columns on desktop */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1.5 text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
                <Mail className="w-3 h-3" />
                Email
              </label>
              <input
                type="email"
                value={settings.email}
                onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                className="w-full px-2.5 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
                placeholder="email@perusahaan.com"
                required
              />
            </div>
            <div>
              <label className="flex items-center gap-1.5 text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
                <Phone className="w-3 h-3" />
                {t('settings.phone')}
              </label>
              <input
                type="tel"
                value={settings.phone}
                onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                className="w-full px-2.5 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
                placeholder="08xxxxxxxxxx"
                required
              />
            </div>
          </div>

          {/* Alamat */}
          <div>
            <label className="flex items-center gap-1.5 text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
              <MapPin className="w-3 h-3" />
              {t('settings.address')}
            </label>
            <textarea
              value={settings.address}
              onChange={(e) => setSettings({ ...settings, address: e.target.value })}
              className="w-full px-2.5 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
              rows={2}
              placeholder="Alamat lengkap perusahaan"
              required
            />
          </div>

          {/* Base URL */}
          <div>
            <label className="flex items-center gap-1.5 text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
              <Globe className="w-3 h-3" />
              Base URL
            </label>
            <input
              type="url"
              value={settings.baseUrl}
              onChange={(e) => setSettings({ ...settings, baseUrl: e.target.value })}
              className="w-full px-2.5 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
              placeholder="https://billing.domain.com"
              required
            />
            <p className="mt-1 text-[10px] text-gray-500">{t('settings.baseUrlHelp')}</p>
          </div>

          {/* Timezone */}
          <div>
            <label className="flex items-center gap-1.5 text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
              🌍 Timezone
            </label>
            <select
              value={settings.timezone}
              onChange={(e) => setSettings({ ...settings, timezone: e.target.value })}
              className="w-full px-2.5 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
              required
            >
              <optgroup label="Indonesia">
                <option value="Asia/Jakarta">WIB - Jakarta, Sumatera, Jawa, Kalimantan Barat/Tengah (UTC+7)</option>
                <option value="Asia/Makassar">WITA - Bali, NTB, NTT, Sulawesi, Kalimantan Selatan/Timur (UTC+8)</option>
                <option value="Asia/Jayapura">WIT - Maluku, Papua (UTC+9)</option>
              </optgroup>
              <optgroup label="Asia Tenggara">
                <option value="Asia/Singapore">Singapore (SGT - UTC+8)</option>
                <option value="Asia/Kuala_Lumpur">Malaysia (MYT - UTC+8)</option>
                <option value="Asia/Bangkok">Thailand (ICT - UTC+7)</option>
                <option value="Asia/Manila">Philippines (PHT - UTC+8)</option>
                <option value="Asia/Ho_Chi_Minh">Vietnam (ICT - UTC+7)</option>
              </optgroup>
              <optgroup label="Asia Lainnya">
                <option value="Asia/Dubai">UAE (GST - UTC+4)</option>
                <option value="Asia/Riyadh">Saudi Arabia (AST - UTC+3)</option>
                <option value="Asia/Tokyo">Japan (JST - UTC+9)</option>
                <option value="Asia/Seoul">South Korea (KST - UTC+9)</option>
                <option value="Asia/Hong_Kong">Hong Kong (HKT - UTC+8)</option>
              </optgroup>
              <optgroup label="Australia & Pacific">
                <option value="Australia/Sydney">Australia Sydney (AEDT - UTC+11)</option>
                <option value="Australia/Melbourne">Australia Melbourne (AEDT - UTC+11)</option>
                <option value="Pacific/Auckland">New Zealand (NZDT - UTC+13)</option>
              </optgroup>
            </select>
            <div className="mt-1.5 p-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
              <p className="text-[10px] text-yellow-800 dark:text-yellow-200">
                ⚠️ <strong>PENTING:</strong> Perubahan timezone akan otomatis update:
              </p>
              <ul className="mt-1 ml-4 text-[10px] text-yellow-700 dark:text-yellow-300 list-disc space-y-0.5">
                <li>Environment variable (.env)</li>
                <li>Timezone utility (src/lib/timezone.ts)</li>
                <li>PM2 configuration (ecosystem.config.js)</li>
                <li>Aplikasi akan restart otomatis</li>
                <li>Semua timestamp akan disesuaikan ke zona waktu baru</li>
              </ul>
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <button
              type="submit"
              disabled={saving || restarting}
              className="flex items-center justify-center gap-1.5 px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-medium rounded-lg transition-colors disabled:opacity-50"
            >
              {saving ? (
                <>
                  <Loader2 className="w-3 h-3 animate-spin" />
                  {t('settings.saving')}
                </>
              ) : (
                <>
                  <Save className="w-3 h-3" />
                  {t('settings.saveSettings')}
                </>
              )}
            </button>
            
            {/* Save & Restart Button - only show when timezone changed */}
            {timezoneChanged && (
              <button
                type="button"
                onClick={handleSaveAndRestart}
                disabled={saving || restarting}
                className="flex items-center justify-center gap-1.5 px-4 py-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-medium rounded-lg transition-colors disabled:opacity-50"
              >
                {restarting ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Restarting...
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3 h-3" />
                    Simpan & Restart Services
                  </>
                )}
              </button>
            )}
          </div>
          
          {/* Timezone change indicator */}
          {timezoneChanged && (
            <div className="mt-2 p-2 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg">
              <p className="text-[10px] text-orange-800 dark:text-orange-200">
                🔄 <strong>Timezone berubah!</strong> Klik "Simpan & Restart Services" untuk menerapkan perubahan timezone ke server (PM2 & FreeRADIUS).
              </p>
            </div>
          )}
        </div>
      </form>
    </div>
  );
}
