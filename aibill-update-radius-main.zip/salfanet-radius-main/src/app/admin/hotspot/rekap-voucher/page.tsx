'use client';

import { useState, useEffect } from 'react';
import { BarChart3, Download, RefreshCw, Filter } from 'lucide-react';
import { useTranslation } from '@/hooks/useTranslation';

interface RekapVoucher {
  batchCode: string;
  createdAt: string;
  agent: {
    id: string;
    name: string;
    phone: string;
  } | null;
  profile: {
    id: string;
    name: string;
  };
  totalQty: number;
  stock: number; // WAITING
  sold: number;  // ACTIVE + EXPIRED
}

export default function RekapVoucherPage() {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [rekap, setRekap] = useState<RekapVoucher[]>([]);
  const [filterAgent, setFilterAgent] = useState('');
  const [filterProfile, setFilterProfile] = useState('');
  const [agents, setAgents] = useState<{ id: string; name: string }[]>([]);
  const [profiles, setProfiles] = useState<{ id: string; name: string }[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchData();
  }, [filterAgent, filterProfile]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filterAgent && filterAgent !== 'all') params.set('agentId', filterAgent);
      if (filterProfile && filterProfile !== 'all') params.set('profileId', filterProfile);

      const res = await fetch(`/api/hotspot/rekap-voucher?${params}`);
      const data = await res.json();
      setRekap(data.rekap || []);
      setAgents(data.agents || []);
      setProfiles(data.profiles || []);
    } catch (error) {
      console.error('Failed to fetch rekap:', error);
    }
    setLoading(false);
  };

  const handleExport = async () => {
    try {
      const params = new URLSearchParams();
      if (filterAgent && filterAgent !== 'all') params.set('agentId', filterAgent);
      if (filterProfile && filterProfile !== 'all') params.set('profileId', filterProfile);
      
      const res = await fetch(`/api/hotspot/rekap-voucher/export?${params}`);
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Rekap-Voucher-${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  };

  const filteredRekap = rekap.filter(item => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      item.batchCode.toLowerCase().includes(search) ||
      item.agent?.name.toLowerCase().includes(search) ||
      item.profile.name.toLowerCase().includes(search)
    );
  });

  const totalQty = filteredRekap.reduce((sum, item) => sum + item.totalQty, 0);
  const totalStock = filteredRekap.reduce((sum, item) => sum + item.stock, 0);
  const totalSold = filteredRekap.reduce((sum, item) => sum + item.sold, 0);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            Rekap Voucher
          </h1>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Rekap voucher per batch dengan informasi agen, qty, stok, dan terjual
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={fetchData}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            <Download className="w-3.5 h-3.5" />
            Export
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              <Filter className="w-3 h-3 inline mr-1" />
              Agen
            </label>
            <select
              value={filterAgent}
              onChange={(e) => setFilterAgent(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800"
            >
              <option value="">Semua Agen</option>
              <option value="all">Semua Agen</option>
              {agents.map(agent => (
                <option key={agent.id} value={agent.id}>{agent.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              <Filter className="w-3 h-3 inline mr-1" />
              Profile
            </label>
            <select
              value={filterProfile}
              onChange={(e) => setFilterProfile(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800"
            >
              <option value="">Semua Profile</option>
              <option value="all">Semua Profile</option>
              {profiles.map(profile => (
                <option key={profile.id} value={profile.id}>{profile.name}</option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Cari (Kode Batch, Agen, Profile)
            </label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Ketik untuk mencari..."
              className="w-full px-2.5 py-1.5 text-xs border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800"
            />
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-800">
          <div className="text-xs text-gray-500 uppercase font-medium mb-1">Total Qty</div>
          <div className="text-2xl font-bold text-blue-600">{totalQty.toLocaleString()}</div>
        </div>
        <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-800">
          <div className="text-xs text-gray-500 uppercase font-medium mb-1">Stok</div>
          <div className="text-2xl font-bold text-green-600">{totalStock.toLocaleString()}</div>
        </div>
        <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-800">
          <div className="text-xs text-gray-500 uppercase font-medium mb-1">Terjual</div>
          <div className="text-2xl font-bold text-orange-600">{totalSold.toLocaleString()}</div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="px-3 py-2 text-left text-[10px] font-medium text-gray-500 uppercase">#</th>
                <th className="px-3 py-2 text-left text-[10px] font-medium text-gray-500 uppercase">Kode Batch</th>
                <th className="px-3 py-2 text-left text-[10px] font-medium text-gray-500 uppercase">Tgl Pembuatan</th>
                <th className="px-3 py-2 text-left text-[10px] font-medium text-gray-500 uppercase">Mitra/Agen</th>
                <th className="px-3 py-2 text-left text-[10px] font-medium text-gray-500 uppercase">Profile</th>
                <th className="px-3 py-2 text-right text-[10px] font-medium text-gray-500 uppercase">Qty</th>
                <th className="px-3 py-2 text-right text-[10px] font-medium text-gray-500 uppercase">Stok</th>
                <th className="px-3 py-2 text-right text-[10px] font-medium text-gray-500 uppercase">Terjual</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {loading ? (
                <tr>
                  <td colSpan={8} className="px-3 py-8 text-center text-gray-500 text-xs">
                    Loading...
                  </td>
                </tr>
              ) : filteredRekap.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-3 py-8 text-center text-gray-500 text-xs">
                    Tidak ada data rekap voucher
                  </td>
                </tr>
              ) : (
                filteredRekap.map((item, index) => (
                  <tr key={item.batchCode} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <td className="px-3 py-2 text-[10px] text-gray-500">{index + 1}</td>
                    <td className="px-3 py-2 text-[10px] font-mono text-gray-900 dark:text-white">
                      {item.batchCode}
                    </td>
                    <td className="px-3 py-2 text-[10px] text-gray-600">
                      {formatDate(item.createdAt)}
                    </td>
                    <td className="px-3 py-2 text-[10px] text-gray-600">
                      {item.agent ? (
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{item.agent.name}</div>
                          <div className="text-gray-500">{item.agent.phone}</div>
                        </div>
                      ) : (
                        <span className="text-gray-400 italic">Admin</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-[10px] text-gray-600">
                      {item.profile.name}
                    </td>
                    <td className="px-3 py-2 text-[10px] text-right font-medium text-blue-600">
                      {item.totalQty}
                    </td>
                    <td className="px-3 py-2 text-[10px] text-right font-medium text-green-600">
                      {item.stock}
                    </td>
                    <td className="px-3 py-2 text-[10px] text-right font-medium text-orange-600">
                      {item.sold}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {filteredRekap.length > 0 && (
              <tfoot className="bg-gray-50 dark:bg-gray-800/50 border-t border-gray-200 dark:border-gray-700">
                <tr className="font-bold">
                  <td colSpan={5} className="px-3 py-2 text-xs text-gray-900 dark:text-white text-right">
                    Total:
                  </td>
                  <td className="px-3 py-2 text-xs text-right text-blue-600">
                    {totalQty.toLocaleString()}
                  </td>
                  <td className="px-3 py-2 text-xs text-right text-green-600">
                    {totalStock.toLocaleString()}
                  </td>
                  <td className="px-3 py-2 text-xs text-right text-orange-600">
                    {totalSold.toLocaleString()}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* Info Footer */}
      <div className="text-xs text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-800/50 p-3 rounded-lg">
        <div className="flex items-start gap-2">
          <div className="mt-0.5">ℹ️</div>
          <div>
            <div className="font-medium mb-1">Keterangan:</div>
            <ul className="list-disc list-inside space-y-0.5">
              <li><strong>Qty:</strong> Total voucher yang dibuat dalam batch tersebut</li>
              <li><strong>Stok:</strong> Voucher yang masih tersedia (status WAITING)</li>
              <li><strong>Terjual:</strong> Voucher yang sudah terpakai (status ACTIVE atau EXPIRED)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
