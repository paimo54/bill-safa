import { NextRequest, NextResponse } from 'next/server'
import { getCronHistory, syncVoucherFromRadius, recordAgentSales, generateInvoices, sendInvoiceReminders, autoIsolateExpiredUsers, disconnectExpiredVoucherSessions } from '@/lib/cron/voucher-sync'

/**
 * GET /api/cron - Get cron history
 */
export async function GET(request: NextRequest) {
  try {
    const history = await getCronHistory()
    
    return NextResponse.json({
      success: true,
      history
    })
  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: error.message
    }, { status: 500 })
  }
}

/**
 * POST /api/cron - Manual trigger cron job
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}))
    const jobType = body.type || 'voucher_sync'
    
    let result: any
    
    switch (jobType) {
      case 'voucher_sync':
        result = await syncVoucherFromRadius()
        return NextResponse.json({
          success: result.success,
          synced: result.synced,
          error: result.error
        })
        
      case 'agent_sales':
        result = await recordAgentSales()
        return NextResponse.json({
          success: result.success,
          recorded: result.recorded,
          error: result.error
        })
        
      case 'invoice_generate':
        result = await generateInvoices()
        return NextResponse.json({
          success: result.success,
          generated: result.generated,
          skipped: result.skipped,
          error: result.error
        })
        
      case 'invoice_reminder':
        result = await sendInvoiceReminders()
        return NextResponse.json({
          success: result.success,
          sent: result.sent,
          skipped: result.skipped,
          error: result.error
        })
        
      case 'notification_check':
        const { NotificationService } = await import('@/lib/notifications')
        result = await NotificationService.runNotificationCheck()
        return NextResponse.json(result)
        
      case 'auto_isolir':
        result = await autoIsolateExpiredUsers()
        return NextResponse.json({
          success: result.success,
          isolated: result.isolated,
          error: result.error
        })
        
      case 'telegram_backup':
        const { autoBackupToTelegram } = await import('@/lib/cron/telegram-cron')
        result = await autoBackupToTelegram()
        return NextResponse.json({
          success: result.success,
          error: result.error
        })
        
      case 'telegram_health':
        const { sendHealthCheckToTelegram } = await import('@/lib/cron/telegram-cron')
        result = await sendHealthCheckToTelegram()
        return NextResponse.json({
          success: result.success,
          error: result.error
        })
        
      case 'disconnect_sessions':
        result = await disconnectExpiredVoucherSessions()
        return NextResponse.json({
          success: result.success,
          disconnected: result.disconnected,
          error: result.error
        })
        
      case 'activity_log_cleanup':
        const { cleanOldActivities } = await import('@/lib/activity-log')
        result = await cleanOldActivities(30)
        return NextResponse.json({
          success: result.success,
          deleted: result.deleted,
          error: result.error
        })
        
      case 'webhook_log_cleanup':
        const { prisma } = await import('@/lib/prisma')
        const { nanoid } = await import('nanoid')
        
        const startedAt = new Date()
        
        // Create history record
        const history = await prisma.cronHistory.create({
          data: {
            id: nanoid(),
            jobType: 'webhook_log_cleanup',
            status: 'running',
            startedAt,
          },
        })
        
        try {
          const cutoffDate = new Date()
          cutoffDate.setDate(cutoffDate.getDate() - 30)
          
          const deleteResult = await prisma.webhookLog.deleteMany({
            where: {
              createdAt: { lt: cutoffDate }
            }
          })
          
          const completedAt = new Date()
          const duration = completedAt.getTime() - startedAt.getTime()
          
          // Update history with success
          await prisma.cronHistory.update({
            where: { id: history.id },
            data: {
              status: 'success',
              completedAt,
              duration,
              result: `Deleted ${deleteResult.count} webhook logs older than 30 days`,
            },
          })
          
          return NextResponse.json({
            success: true,
            deleted: deleteResult.count,
            cutoffDate: cutoffDate.toISOString(),
            message: `Deleted ${deleteResult.count} webhook logs older than 30 days`
          })
        } catch (cleanupError: any) {
          // Update history with error
          await prisma.cronHistory.update({
            where: { id: history.id },
            data: {
              status: 'error',
              completedAt: new Date(),
              error: cleanupError.message,
            },
          })
          
          return NextResponse.json({
            success: false,
            deleted: 0,
            error: cleanupError.message
          })
        }
        
      default:
        return NextResponse.json({
          success: false,
          error: 'Invalid job type'
        }, { status: 400 })
    }
  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: error.message
    }, { status: 500 })
  }
}
