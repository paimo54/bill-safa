import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { promises as fs } from 'fs';
import path from 'path';

export async function POST(req: NextRequest) {
  try {
    // Check if this is an internal call (from company API) or external
    const isInternalCall = req.headers.get('x-internal-call') === 'true';
    
    if (!isInternalCall) {
      const session = await getServerSession(authOptions);
      if (!session || session.user.role !== 'SUPER_ADMIN') {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      }
    }

    const { timezone } = await req.json();

    if (!timezone) {
      return NextResponse.json({ error: 'Timezone is required' }, { status: 400 });
    }

    const results = {
      envFile: false,
      timezoneLib: false,
      ecosystemConfig: false,
      errors: [] as string[],
    };

    // 1. Update .env file
    try {
      const envPath = path.join(process.cwd(), '.env');
      let envContent = await fs.readFile(envPath, 'utf-8');
      
      // Update or add TZ and NEXT_PUBLIC_TIMEZONE
      const tzRegex = /^TZ=.*$/m;
      const nextPublicTzRegex = /^NEXT_PUBLIC_TIMEZONE=.*$/m;
      
      if (tzRegex.test(envContent)) {
        envContent = envContent.replace(tzRegex, `TZ="${timezone}"`);
      } else {
        envContent += `\nTZ="${timezone}"`;
      }
      
      if (nextPublicTzRegex.test(envContent)) {
        envContent = envContent.replace(nextPublicTzRegex, `NEXT_PUBLIC_TIMEZONE="${timezone}"`);
      } else {
        envContent += `\nNEXT_PUBLIC_TIMEZONE="${timezone}"`;
      }
      
      await fs.writeFile(envPath, envContent, 'utf-8');
      results.envFile = true;
    } catch (error: any) {
      results.errors.push(`env file: ${error.message}`);
    }

    // 2. Update src/lib/timezone.ts
    try {
      const timezonePath = path.join(process.cwd(), 'src', 'lib', 'timezone.ts');
      let timezoneContent = await fs.readFile(timezonePath, 'utf-8');
      
      // Update WIB_TIMEZONE constant (keep name as WIB_TIMEZONE for backward compatibility)
      const wibTimezoneRegex = /export const WIB_TIMEZONE = ['"].*?['"];/;
      timezoneContent = timezoneContent.replace(
        wibTimezoneRegex,
        `export const WIB_TIMEZONE = '${timezone}';`
      );
      
      // Update LOCAL_TIMEZONE if exists
      const localTimezoneRegex = /export const LOCAL_TIMEZONE = ['"].*?['"];/;
      if (localTimezoneRegex.test(timezoneContent)) {
        timezoneContent = timezoneContent.replace(
          localTimezoneRegex,
          `export const LOCAL_TIMEZONE = '${timezone}';`
        );
      }
      
      await fs.writeFile(timezonePath, timezoneContent, 'utf-8');
      results.timezoneLib = true;
    } catch (error: any) {
      results.errors.push(`timezone.ts: ${error.message}`);
    }

    // 3. Update ecosystem.config.js
    try {
      const ecosystemPath = path.join(process.cwd(), 'ecosystem.config.js');
      let ecosystemContent = await fs.readFile(ecosystemPath, 'utf-8');
      
      // Update TZ in env object
      const tzEnvRegex = /TZ:\s*['"].*?['"]/g;
      ecosystemContent = ecosystemContent.replace(tzEnvRegex, `TZ: '${timezone}'`);
      
      await fs.writeFile(ecosystemPath, ecosystemContent, 'utf-8');
      results.ecosystemConfig = true;
    } catch (error: any) {
      results.errors.push(`ecosystem.config.js: ${error.message}`);
    }

    // Check if all updates were successful
    const allSuccess = results.envFile && results.timezoneLib && results.ecosystemConfig;

    if (allSuccess) {
      return NextResponse.json({
        success: true,
        message: 'Timezone updated successfully. Please restart the application.',
        results,
        restartRequired: true,
      });
    } else {
      return NextResponse.json({
        success: false,
        message: 'Some updates failed',
        results,
      }, { status: 500 });
    }
  } catch (error: any) {
    console.error('Timezone update error:', error);
    return NextResponse.json(
      { error: 'Failed to update timezone', details: error.message },
      { status: 500 }
    );
  }
}
